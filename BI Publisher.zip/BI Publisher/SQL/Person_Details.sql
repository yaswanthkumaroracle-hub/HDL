select papf.person_number PERSON_NUMBER,
ppnf.display_name PERSON_NAME,
TO_CHAR(ppos.date_start,'DD/MM/YYYY') DATE_START,
/* LENGTH OF SERVICE
DATE+OF_BIRTH,
PRIMARY EMAIL ADDRESS,
PRIMARY MAILING ADDRESS*/
PJ.NAME JOB_NAME,
HAP.NAME POSITION_NAME,
HAOU.NAME DEPT_NAME,
BU_NAME.NAME BU_NAME,
nvl(paam.WORK_AT_HOME, 'NULL') wfh,
nvl(paam.MANAGER_FLAG, 'NULL') Manager_Flag,
FLV.MEANING Reg_Temp,
paam.NORMAL_HOURS ||' '|| FLV_Freq.MEANING Working_Hours,
FLV_sal.MEANING Paid_By
,LE_NAME.NAME LE_NAME
,paam.ACTION_CODE ACTION_CODE
,paam.REASON_CODE Action_Reason
,PG.NAME Grade
,HLA.LOCATION_NAME Location_NAME
,pptv.USER_PERSON_TYPE  person_type
,TO_CHAR(pp.DATE_OF_BIRTH, 'DD/MM/YYYY') DOB
,pea.EMAIL_ADDRESS Email
,paf.ADDRESS_LINE_1||' '||paf.ADDRESS_LINE_2||' '||paf.ADDRESS_LINE_3||' '||paf.COUNTRY||' '||paf.POSTAL_CODE MAILING_ADDRESS
,round(MONTHS_BETWEEN(trunc(sysdate), trunc(ppos.date_start)),2) LOS_Months
,round(MONTHS_BETWEEN(trunc(sysdate), trunc(ppos.date_start))*(365/12),2) LOS_DAYS
,round(MONTHS_BETWEEN(trunc(sysdate), trunc(ppos.date_start))/12,2) LOS_YEARS
-- ,ppav.ADDRESS_LINE_1||' '||ppav.ADDRESS_LINE_2||' '||ppav.POSTAL_CODE MAILING_ADDRESS





from
per_all_people_f papf
,per_person_names_f ppnf
,per_all_assignments_m paam
,per_periods_of_service ppos
,PER_JOBS_F_VL PJ
,HR_ALL_POSITIONS_F_VL HAP
,HR_ALL_ORGANIZATION_UNITS HAOU
,HR_ALL_ORGANIZATION_UNITS BU_NAME
,HR_ALL_ORGANIZATION_UNITS LE_NAME
,PER_GRADES PG
,HR_LOCATIONS_ALL_F_VL HLA
,PER_PERSON_TYPES_VL pptv
,PER_PERSONS pp
,PER_EMAIL_ADDRESSES pea
,FND_LOOKUP_VALUES FLV
,FND_LOOKUP_VALUES FLV_Freq
,FND_LOOKUP_VALUES FLV_sal
,PER_ADDRESSES_F paf
-- ,PER_PERSON_ADDRESSES_V ppav

   


 
where 1=1

and papf.person_id = ppnf.person_id
and papf.person_id = paam.person_id
and paam.period_of_service_id = ppos.period_of_service_id
AND PAAM.JOB_ID = PJ.JOB_ID(+)
AND PAAM.POSITION_ID = HAP.POSITION_ID(+)
AND PAAM.ORGANIZATION_ID = HAOU.ORGANIZATION_ID
AND PAAM.BUSINESS_UNIT_ID = BU_NAME.ORGANIZATION_ID
AND PAAM.LEGAL_ENTITY_ID = LE_NAME.ORGANIZATION_ID
AND PAAM.GRADE_ID = PG.GRADE_ID
AND PAAM.LOCATION_ID = HLA.LOCATION_ID
AND paam.person_type_id = pptv.person_type_id
AND papf.person_id = pp.person_id
AND papf.PRIMARY_EMAIL_ID = pea.EMAIL_ADDRESS_ID
-- AND PAPF.PERSON_ID = PA.PERSON_ID
AND papf.MAILING_ADDRESS_ID = paf.ADDRESS_ID
-- AND papf.person_id = ppav.person_id
-- AND papf.mailing_address_id = ppav.address_id(+)





 

and ppnf.name_type = 'GLOBAL'
and paam.assignment_type = 'E'
and paam.primary_flag = 'Y'
and paam.assignment_status_type = 'ACTIVE'
 
/*CODE TO JOIN LOOKUPS*/
AND FLV.LOOKUP_TYPE(+) = 'REGULAR_TEMPORARY'
AND PAAM.PERMANENT_TEMPORARY_FLAG(+) = FLV.LOOKUP_CODE
AND FLV.LANGUAGE(+) = 'US'

AND FLV_Freq.LOOKUP_TYPE = 'FREQUENCY'
AND PAAM.FREQUENCY = FLV_Freq.LOOKUP_CODE
AND FLV_Freq.LANGUAGE = 'US' 

AND FLV_sal.LOOKUP_TYPE = 'HOURLY_SALARIED_CODE'
AND PAAM.HOURLY_SALARIED_CODE = FLV_sal.LOOKUP_CODE
AND FLV_sal.LANGUAGE = 'US'
 
 
and trunc(sysdate) between papf.effective_start_date and papf.effective_end_date
and trunc(sysdate) between ppnf.effective_start_date and ppnf.effective_end_date
and trunc(sysdate) between paam.effective_start_date and paam.effective_end_date
and trunc(sysdate) between HAP.effective_start_date and HAP.effective_end_date
and trunc(sysdate) between PJ.effective_start_date and PJ.effective_end_date
and trunc(sysdate) between HLA.effective_start_date and HLA.effective_end_date
-- AND TRUNC(SYSDATE) BETWEEN PPAV.EFFECTIVE_START_DATE AND PPAV.EFFECTIVE_END_DATE
AND TRUNC(SYSDATE) BETWEEN paf.EFFECTIVE_START_DATE AND paf.EFFECTIVE_END_DATE

order by papf.person_number