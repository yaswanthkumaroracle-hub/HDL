SELECT DISTINCT pn.first_name
     , pn.last_name
     , ppf.person_number
     , ppf.person_id
     , pdccd.base_component_name           card_component_name
     , pvd.base_name                       value_def_base_name
     , pri.value1                          absence_value
     , NVL( uom.meaning, pvd.uom )         uom
     , NVL( prd.meaning, pvd.periodicity ) dir_periodicity 
     , pdc.creator_id                     pdcc_creator_id 
     , pdc.creator_type                   pdcc_creator_type 
     , pdcc.effective_start_date        
     , pdcc.effective_end_date 
     , TO_CHAR(pdcc.effective_start_date)   chr_start_dt 
     , TO_CHAR(pdcc.effective_end_date)     chr_end_dt 
     , pdc.legislative_data_group_id  
     , pvd.creation_date
FROM 
     per_all_people_f          ppf
   , per_person_names_f        pn
   , pay_pay_relationships_dn  reldn
   , pay_dir_card_components_f pdcc
   , pay_dir_cards_f           pdc
   , pay_dir_card_comp_defs_f  pdccd
   , pay_value_definitions_f   pvd
   , hr_lookups                uom 
   , hr_lookups                prd
   , pay_calc_types            pct1
   , pay_range_items_f         pri
   , pay_calc_types            pct2
   , pay_allow_overrides_f     pao
   , pay_dir_override_usages_f pou
WHERE 
    (     ppf.person_number = :pPersonNumber
      OR :pPersonNumber IS NULL )
AND pn.person_id                       = ppf.person_id
AND NVL(:pStartDate, TRUNC(SYSDATE))   BETWEEN ppf.effective_start_date AND ppf.effective_end_date
AND NVL(:pStartDate, TRUNC(SYSDATE))   BETWEEN pn.effective_start_date  AND pn.effective_end_date
AND pn.name_type                       = 'GLOBAL'
AND reldn.person_id                    = ppf.person_id
AND pdc.payroll_relationship_id        = reldn.payroll_relationship_id
AND pdcc.dir_card_id                   = pdc.dir_card_id
AND pdccd.dir_card_comp_def_id         = pdcc.dir_card_comp_def_id
AND pdccd.base_component_name          LIKE :pBaseComponentName || '%'
AND pdc.legislative_data_group_id      = NVL( :pLdgId, pdc.legislative_data_group_id )
AND pdc.creator_type                   = 'ABSXML'
AND pvd.source_id                     = pdcc.dir_card_comp_id
AND pvd.source_type                    = 'PDCC'
AND uom.lookup_type(+)                 = 'ABSENCE_ELEMENTS_UOM'
AND uom.lookup_code(+)                 = pvd.uom
AND prd.lookup_type(+)                 = 'PAY_UOM'
AND prd.lookup_code(+)                 = pvd.periodicity
AND TRUNC( pdcc.effective_start_date ) BETWEEN :pStartDate AND :pEndDate
AND pct1.calc_type_id (+)             = pvd.calc_type_id
AND pri.value_defn_id (+)             = pvd.value_defn_id
AND pvd.dir_override_usage_id         = pou.dir_override_usage_id (+)
AND pou.allow_overrides_id            = pao.allow_overrides_id (+)
AND pri.calc_type_id                  = pct2.calc_type_id (+)