/*Requirement - Fetch the details of Absence - Plan Name, Plan Type, Eligibility Profile Name */

SELECT DISTINCT DECODE(AAP.ENTL_METHOD_CD, 'A', 'ACCRUAL PLAN',
										 'N', 'NO ENTITLEMENT PLAN',
										 'Q', 'QUALIFICATION PLAN',
										 'ORA_ANC_COMP', 'COMPENSATORY PLAN',
										 'ORA_ANC_DON', 'DONATION PLAN',
										 'ORA_ANC_AGREE', 'AGREEMENT PLAN') Plan_Type
	,APEP.BEN_ELIG_PROFILE_ID Eligibility_ID
	,AAP.BASE_NAME Plan_Name
	,BEP.Name Eligibility_Name
	





FROM ANC_ABSENCE_PLANS_F AAP
	,ANC_PLAN_ELIG_PROFILES_F APEP
	,BEN_ELIGY_PRFL BEP
	
	
WHERE 1=1
	AND APEP.ABSENCE_PLAN_ID = AAP.ABSENCE_PLAN_ID
	AND APEP.BEN_ELIG_PROFILE_ID = BEP.ELIGY_PRFL_ID